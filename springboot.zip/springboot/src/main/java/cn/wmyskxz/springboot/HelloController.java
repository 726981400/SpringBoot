package cn.wmyskxz.springboot;
import com.fasterxml.jackson.core.format.DataFormatDetector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.DateFormat;
import java.util.Date;


//@RestController//该注解是 @Controller 和 @ResponseBody 注解的合体版
@Controller
public class HelloController {
//    @Value("${name}")
//    private String name;
//
//    @Value("${age}")
//    private String age;
//
//    @Value("${content}")
//    private String content;
//
//    @Autowired
//    private StudentProperties studentProperties;

    @RequestMapping("/hello")
    public String hello(Model m){
        m.addAttribute("now", DateFormat.getDateTimeInstance().format(new Date()));
        return "hello";
    }


}
