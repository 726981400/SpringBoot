package cn.wmyskxz.springboot.pojo;

import java.util.Date;

public class Student {

    private Integer id;
    private Integer student_id;
    private String name;
    private Integer age;
    private String sex;
    private Date birthday;

    /* getter and setter */
}

